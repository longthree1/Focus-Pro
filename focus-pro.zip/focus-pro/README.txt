FB Reel Focus Pro v1.4

Cập nhật v1.4:
- Sửa lỗi control không tự ẩn khi để yên chuột.
- Bỏ logic :hover toàn màn hình làm timer bị kẹt.
- Control ẩn sau 3 giây thật sự, kể cả khi chuột nằm yên trên màn hình.
- Di chuyển chuột thật mới hiện lại control.
- Khi control đang ẩn, ←/→ vẫn tua và không làm hiện control.
- Khi control đang hiện, ←/→ tua xong vẫn giữ control hiện rồi tự ẩn sau 3 giây.
- UI icon-only, gọn, không có thanh trên đầu.

Phím tắt:
Alt+Z: Focus đầy màn
Alt+V: Vừa màn
Alt+F: Fullscreen thật
Alt+X: Thoát Focus
Space: Play/Pause
← / →: Tua 5 giây
+ / -: Zoom
Alt+A: Bật/tắt khóa âm
M: Tắt/bật tiếng thủ công

Cài đặt:
1. Giải nén zip.
2. Mở chrome://extensions hoặc edge://extensions.
3. Bật Developer mode.
4. Load unpacked thư mục fb-reel-focus-pro.
